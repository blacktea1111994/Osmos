Vitajte v hre OSMOS.

Po spustení hry sa zobrazí vľavo herné menu s buttonami a 
vpravo hracia plocha.

Hra obsahuje 4 levely, ktorých náročnosť sa zvyšuje:
	0 - tutorial
	1 - easy
	2 - medium
	3 - hard
+ RANDOM level -ktorý vygeneruje náhodnú mapu.

OVLÁDANIE: pomocou myši po kliknuti do hracej plochy je 
	   smerom ku miestu kliknutia zhmotnená časť hráčovej hmotnosti
	   za účelom zvýšenia rýchlosti a koordinácie smeru.

Pri stretnutí buniek dochádza k výmene hmotnosti a rýchlosti z
menšej bunky do väčšej, pričom menšia môže zaniknúť.
Hráč ovláda svetlomodrú bunku, pričom rozdiel hmotnosti je určený farbou
okolitých buniek. TMAVOMODRA má menšiu hmotnosť ako naša bunka 
		  ČERVENÁ väčšiu.

Cieľom hry je dosiahnuť danú hmotnosť zobrazenú v strede hore na hracej ploche.
Ak hráč prehrá alebo vyhrá, môže daný level reštartovať. Počas hry je možné
si stav hry uložiť pomocou buttonu SAVE a kedykoľvek načítať posledný uložený 
stav pomocou buttonu LOAD.

Počas hry si vychutnajte príjemný ambient. Prajem veľa zábavy a oddychu 
s OSMOS.