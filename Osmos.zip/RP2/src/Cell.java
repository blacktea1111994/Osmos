public interface Cell{
    void move();
    void update(double radius, PlayerCell player);

    double getCenterX();
    boolean getBlue();
    double getCenterY();
    double getRadius();
    double getDirX();
    double getDirY();
    double getM();

    void setCenterX(double centerX);
    void setCenterY(double centerX);
    void setRadius(double radius);
    void setDirX(double dirX);
    void setDirY(double dirY);
    void setM(double m);
}
