import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.SplitPane;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.io.*;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * project OSMOS
 * @author Jakub Toma
 */

public class Osmos extends Application {
    Menu menu;
    UniversePane pane;
    SplitPane splitpane;

    private double WIDTH = 1320;
    private double HEIGHT = 800;
    boolean failed;
    boolean complete;
    double goal;
    Text goalInfo = new Text();

    static Image blueImg = new Image("img/blueCell.png");
    static Image redImg = new Image("img/redCell.png");
    final static ImagePattern BLUE = new ImagePattern(blueImg);
    final static ImagePattern RED = new ImagePattern(redImg);

    final int VECTOR_NORMALIZER = 25;
    final double EJECTED_WEIGHT_PERCENTAGE = 0.025;
    final int MINIMUM_PLAYER_WEIGHT = 5;

    final static double SLOWDOWN = 0.998;
    final static double c = 4;

    public CopyOnWriteArrayList<Cell> cells = new CopyOnWriteArrayList<>();
    static PlayerCell player = null;
    static String chosenLevel = "None";

    @Override
    public void start(Stage primaryStage) {

        MediaPlayer mp = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getClassLoader().getResource("sound/Gas-Discovery.mp3")).toString()));
        mp.setAutoPlay(true);
        mp.setCycleCount(MediaPlayer.INDEFINITE);
        mp.setOnEndOfMedia(mp::play);

        double MENU_WIDTH = 180;
        menu = new Menu(pane, MENU_WIDTH,HEIGHT);
        pane = new UniversePane();
        splitpane = new SplitPane();
        splitpane.setDividerPositions(0.12,0.88);
        splitpane.getItems().addAll(menu,pane);

        Scene scena = new Scene(splitpane,WIDTH+ MENU_WIDTH,HEIGHT);
        scena.getStylesheets().addAll(this.getClass().getResource("style.css").toExternalForm());

        buttonClick(menu.b0,0);
        buttonClick(menu.b1,1);
        buttonClick(menu.b2,2);
        buttonClick(menu.b3,3);
        buttonClick(menu.b4,4);
        buttonClick(menu.b5,5);
        buttonClick(menu.b6,6);
        buttonClick(menu.b7,7);

        pane.setOnMouseClicked(e->{
            if("None".equals(chosenLevel)) return;
            double x = e.getX();
            double y = e.getY();

            if(player == null) player = new PlayerCell(pane,0,0,0,0,0);
            double vektorX = player.centerX-x;
            double vektorY = player.centerY-y;
            double dlzkaVektora = Math.sqrt(Math.pow(vektorX,2)+Math.pow(vektorY,2));

            vektorX = vektorX  / dlzkaVektora * VECTOR_NORMALIZER;
            vektorY = vektorY  / dlzkaVektora * VECTOR_NORMALIZER;

            double m_pred = player.m;
            double m_out = player.m * EJECTED_WEIGHT_PERCENTAGE;

            if(player.m > MINIMUM_PLAYER_WEIGHT) {
                player.m -= m_out;
            }
            double m_po = player.m;
            player.radius = Math.sqrt(player.m) * Osmos.c;
            player.setRadius(player.radius);

            double v_outX = -vektorX;
            double v_outY = -vektorY;

            double v_predX = player.dirX;
            double v_predY = player.dirY;

            double v_poX = ((v_predX * m_pred) - (v_outX * m_out))/ m_po;
            double v_poY = ((v_predY * m_pred) - (v_outY * m_out))/ m_po;

            player.dirX = v_poX;
            player.dirY = v_poY;

            EjectedCell ejected = new EjectedCell(pane, player.centerX + (v_outX / (VECTOR_NORMALIZER-10) * player.radius),
                    player.centerY + (v_outY / (VECTOR_NORMALIZER-10) * player.radius),
                    v_predX+v_outX, v_predY+v_outY,m_out);
            cells.add(ejected);
            pane.getChildren().add(ejected);

        });

        scena.addEventFilter(KeyEvent.KEY_PRESSED,
                event -> {
                    if (failed && event.getCode() == KeyCode.SPACE) {
                        newGame(chosenLevel);
                        failed = false;
                    }
                    if (complete && event.getCode() == KeyCode.SPACE) {
                        newGame(chosenLevel);
                        complete = false;
                    }
                });


        Timeline timeline = new Timeline(new KeyFrame(Duration.millis(25), e -> {
            for(Cell cellA : cells){
                cellA.move();
                showGoal();
                if(player.m >= goal){
                    if(!complete) quote(new Text("You WON!!! press Space to Restart."), Color.LIGHTGREEN);
                    complete = true;
                }

                if(!isAlive(cellA)){
                    if(cellA == player && !complete){
                        quote(new Text("You failed, press Space to Restart."), Color.RED);
                        player.m = 0;
                        failed = true;
                    }
                    continue;
                }
                for(Cell cellB : cells){
                    if(cellA != cellB){
                        if(collision(cellA,cellB)){
                            if(cellA == player || cellB == player) {
                                collisionSound();
                            }
                            diffusion(cellA,cellB);
                        }

                        if(cellA.getCenterX() - cellA.getRadius() <= 0) cellA.setCenterX(cellA.getRadius()+1);
                        if(cellA.getCenterX() + cellA.getRadius() >= pane.getWidth()) cellA.setCenterX(pane.getWidth()-cellA.getRadius()-1);
                        if(cellA.getCenterY() - cellA.getRadius() <= 0) cellA.setCenterY(cellA.getRadius()+1);
                        if(cellA.getCenterY() + cellA.getRadius() >= pane.getHeight()) cellA.setCenterY(pane.getHeight()-cellA.getRadius()-1);

                        cellA.update(cellA.getM(),player);
                        cellB.update(cellB.getM(),player);
                    }
                }
            }
        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();

        primaryStage.setScene(scena);
        primaryStage.setTitle("Osmos");
        primaryStage.getIcons().add(new Image("/img/icon.png"));
        primaryStage.show();
    }

    /**
     *kontroluje ci doslo ku kolizii medzi 2 bunkami
     * @param cellA - prva bunka
     * @param cellB - druha bunka
     */
    public boolean collision(Cell cellA, Cell cellB){
        double distance;
        distance = Math.sqrt(Math.pow((cellA.getCenterX() - cellB.getCenterX()), 2)
                + Math.pow((cellA.getCenterY() - cellB.getCenterY()), 2));
        return distance <= (cellA.getRadius() + cellB.getRadius());
    }

    /**
     * zvuk pri kolizii
     */
    public void collisionSound(){
        MediaPlayer mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getClassLoader().getResource("sound/ConsumedPart.mp3")).toString()));
        mediaPlayer.setVolume(0.1);
        mediaPlayer.play();
    }

    /**
     * presun hmotnosti a rychlosti medzi 2 bunkami
     * @param cellA - vacsia bunka
     * @param cellB - mensia bunka
     */
    public void diffusion(Cell cellA, Cell cellB) {
        double mA = cellA.getM();
        double mB = cellB.getM();

        double deltaWeight = 10;
        if(mA >= mB){
            if(mA > 100) deltaWeight = Math.sqrt(mA);
            if(mB - deltaWeight <= 0) {
                deltaWeight = mB;
            }

            double M_po = mA + deltaWeight;
            cellA.setM(M_po);
            cellB.setM(mB - deltaWeight);

            double V_poX = (cellA.getDirX()*mA+cellB.getDirX()*deltaWeight)/M_po;
            double V_poY = (cellA.getDirY()*mA+cellB.getDirY()*deltaWeight)/M_po;

            cellA.setDirX(V_poX);
            cellA.setDirY(V_poY);
        }
    }

    /**
     * zistuje existenciu bunky v zavislosti od jej hmotnosti
     * @param cell - pri hmotnosti = 0 zmaze bunku a vrati false, inak true
     * */
    public boolean isAlive(Cell cell){
        if(cell.getM() <= 0){
            pane.getChildren().remove(cell);
            cells.remove(cell);
            return false;
        }
        return true;
    }

    /**
     * vytvori textovu hlasku na zaklade vstupnych parametrov
     * @param quote - obsah textu
     * @param color - farba textu
     **/
    public void quote(Text quote, Color color) {
        quote.setX(WIDTH * 2 / 5);
        quote.setY(pane.getHeight() * 15 / 16);
        quote.setFill(color);
        quote.setStyle("-fx-font: 16 system;");
        pane.getChildren().add(quote);
    }

    /**
     * vypise nazov prehravajucej piesne
     * @param name - aktualny soundtrack
     */
    public void soundtrackInfo(String name){
        Text soundtrackInfo = new Text(WIDTH - 200,pane.getHeight() - 30,name);
        soundtrackInfo.setFill(Color.LIGHTSLATEGRAY);
        soundtrackInfo.setStyle("-fx-font: 14 system;");
        pane.getChildren().add(soundtrackInfo);
    }

    /** vypise aktualny level
     * @param name - aktualny level
     */
    public void levelInfo(String name){
        Text levelInfo = new Text(25,pane.getHeight() - 30,"Level: "+name.toUpperCase());
        levelInfo.setFill(Color.LIGHTSLATEGRAY);
        levelInfo.setStyle("-fx-font: 14 system;");
        pane.getChildren().add(levelInfo);
    }

    /** nastavi jednotlive buttony
     * @param button - konkretny button
     * @param i - index buttonu
     */
    public void buttonClick(Button button, int i){
        button.setOnMouseClicked(e -> {
            switch (i){
                case 0: {
                    newGame("0");
                    break;
                }
                case 1: {
                    newGame("1");
                    break;
                }
                case 2:{
                    newGame("2");
                    break;
                }
                case 3: {
                    newGame("3");
                    break;
                }
                case 4: {
                    newGame("random");
                    break;
                }
                case 5: {
                    saveGame();
                    break;
                }
                case 6: {
                    loadGame("src/save/savegame.txt");
                    break;
                }
                case 7: {
                    Platform.exit();
                    System.exit(0);
                }
            }
        });
        DropShadow borderGlow= new DropShadow();
        borderGlow.setOffsetY(0);
        borderGlow.setOffsetX(0);
        borderGlow.setColor(Color.rgb(35,35+30*i,255));
        borderGlow.setWidth(70);
        borderGlow.setHeight(70);

        button.setOnMouseEntered(e -> button.setEffect(borderGlow));
        button.setOnMouseExited(e -> button.setEffect(null));
    }

    /**
     * vytvorenie novej hry podla
     * @param level - konkretny nazov levelu
     * vytvorenie "random" mapy / nacitanie levelu zo suboru
     */
    public void newGame(String level){
        cells.clear();
        pane.getChildren().clear();
        complete = false;
        failed = false;

        if("0".equals(level)){
            chosenLevel = "0";
            loadGame("src/levels/level0.txt");
        }
        if("1".equals(level)){
            chosenLevel = "1";
            loadGame("src/levels/level1.txt");
        }
        if("2".equals(level)){
            chosenLevel = "2";
            loadGame("src/levels/level2.txt");
        }
        if("3".equals(level)){
            chosenLevel = "3";
            loadGame("src/levels/level3.txt");
        }
        else if("random".equals(level)) {
            chosenLevel = "random";
            goal = 500;

            player = new PlayerCell(pane, WIDTH / 2, HEIGHT / 2, 0, 0, 100);
            cells.add(player);
            pane.getChildren().add(player);

            Random rnd = new Random();
            for (int i = 0; i < rnd.nextInt(5)+15; i++) {
                EjectedCell cell = new EjectedCell(pane, rnd.nextInt((int) WIDTH - 50) + 25, rnd.nextInt((int) HEIGHT - 50) + 25, rnd.nextInt(10) - 5, rnd.nextInt(10) - 5, rnd.nextInt(100) + 25);
                cells.add(cell);
                pane.getChildren().add(cell);
            }
        }
        showGoal();
        levelInfo(chosenLevel);
        soundtrackInfo("soundtrack: Gas-Discovery");
    }

    /**
     * zobrazi velkost bunky a cielovu hmotnost
     */
    public void showGoal(){
        pane.getChildren().remove(goalInfo);
        if(player != null) {
            if (player.m >= goal) {
                goalInfo.setText("BECOME HUGE :)\n" + goal + "/" + goal);
            } else {
                goalInfo.setText("BECOME HUGE :)\n" + String.format("%.1f", player.m) + " / " + goal);
            }
            goalInfo.setX(WIDTH * 2 / 5);
            goalInfo.setY(pane.getHeight() * 1 / 16);
            goalInfo.setFill(Color.LIGHTGRAY);
            goalInfo.setStyle("-fx-font: 20 system;"+
                    "-fx-font-weight: bold");
            goalInfo.setTextAlignment(TextAlignment.CENTER);
            pane.getChildren().add(goalInfo);
        }
    }

    /**
     * zapisanie stavu hry do suboru
     */
    public void saveGame(){
        try {
            BufferedWriter bw;
            bw = new BufferedWriter(
                    new OutputStreamWriter(new FileOutputStream("src/save/savegame.txt")));
            bw.write("");
            bw.write("level "+chosenLevel+" "+goal+" "+complete+" "+failed+"\n");
            for (Cell cl: cells) {
                if (cl.getClass().equals(PlayerCell.class)){
                    bw.write("player "+cl.getCenterX()+" "+cl.getCenterY()+" "+cl.getDirX()+" "+cl.getDirY()+" "+cl.getM()+"\n"); }
                else{
                    bw.write("other "+cl.getCenterX()+" "+cl.getCenterY()+" "+cl.getDirX()*c+" "+cl.getDirY()*c+" "+cl.getM()+"\n"); }
            }
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * nacitanie stavu hry zo suboru
     * @param fileName - cesta a nazov suboru
     */
    public void loadGame(String fileName){
        pane.getChildren().clear();
        cells.clear();
        try {
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            String row;
            while ((row = br.readLine()) != null) {
                String[] rowS = row.split(" ");
                switch (rowS[0]) {
                    case "level":
                        chosenLevel = rowS[1];
                        goal = Double.parseDouble(rowS[2]);
                        complete = Boolean.parseBoolean(rowS[3]);
                        failed = Boolean.parseBoolean(rowS[4]);
                        break;
                    case "player":
                        player = new PlayerCell(pane, Double.parseDouble(rowS[1]), Double.parseDouble(rowS[2]),
                                Double.parseDouble(rowS[3]), Double.parseDouble(rowS[4]),
                                Double.parseDouble(rowS[5]));
                        pane.getChildren().add(player);
                        cells.add(player);
                        break;
                    case "other":
                        EjectedCell ej = new EjectedCell(pane, Double.parseDouble(rowS[1]), Double.parseDouble(rowS[2]),
                                Double.parseDouble(rowS[3]), Double.parseDouble(rowS[4]),
                                Double.parseDouble(rowS[5]));
                        pane.getChildren().add(ej);
                        cells.add(ej);
                        break;
                }
            }
            levelInfo(chosenLevel);
            soundtrackInfo("soundtrack: Gas-Discovery");
            if(failed) {
                quote(new Text("You failed, press Space to Restart."),Color.RED);
            }
            if(complete) {
                quote(new Text("You WON!!! press Space to Restart."),Color.LIGHTGREEN);
            }
            if(player == null) player = new PlayerCell(pane, 0, 0, 0, 0, 0);
            showGoal();
            br.close();
        }
        catch (IOException ignored){
        }
    }

    /**
     * main
     */
    public static void main(String[] args) {
        launch(args);
    }
}

class PlayerCell extends Circle implements Cell{
    transient UniversePane p;
    double centerX, centerY;
    double dirX, dirY;
    double m;
    double radius;

    /**
     * konstruktor bunky hraca
     * @param p - pane
     * @param centerX - stred bunky suradnica X
     * @param centerY - stred bunky suradnica Y
     * @param dirX - vektor v smere suradnice X
     * @param dirY - vektor v smere suradnice Y
     * @param m - hmotnost bunky
     */
    public PlayerCell(UniversePane p, double centerX, double centerY, double dirX, double dirY, double m){
        this.p = p;

        this.centerX = centerX;
        this.centerY = centerY;
        this.dirX = dirX;
        this.dirY = dirY;

        this.m = m;
        this.radius = Math.sqrt(m) * Osmos.c;

        setFill(new ImagePattern(new Image("img/icon.png")));
        setCenterX(centerX);
        setCenterY(centerY);
        setRadius(radius);
    }

    /**
     * pohyb bunky hraca a odrazanie od stien
     */
    public void move(){
        if (getLayoutBounds().getMaxX() + dirX > p.getWidth() || getLayoutBounds().getMinX() + dirX < 0) {
            dirX = -dirX;
        }
        if (getLayoutBounds().getMaxY()  + dirY > p.getHeight() || getLayoutBounds().getMinY() + dirY < 0) {
            dirY = -dirY;
        }
        centerX += dirX;
        centerY += dirY;
        setCenterX(centerX);
        setCenterY(centerY);

        dirX *= Osmos.SLOWDOWN;
        dirY *= Osmos.SLOWDOWN;
    }

    /**
     * updatne radius bunky
     * @param player - bunka hraca
     * @param radius - polomer bunky
     */
    public void update(double radius, PlayerCell player){
        setRadius(Math.sqrt(getM()) * Osmos.c);
    }

    public boolean getBlue(){
        return false;
    }
    public double getDirX() {
        return dirX;
    }
    public double getDirY() {
        return dirY;
    }
    public double getM() {
        return m;
    }
    public void setDirX(double dirX) {
        this.dirX = dirX;
    }
    public void setDirY(double dirY) {
        this.dirY = dirY;
    }
    public void setM(double m) {
        this.m = m;
    }
}

class EjectedCell extends Circle implements Cell{
    transient UniversePane p;
    double centerX, centerY;
    double dirX, dirY;
    double m;
    double radius;
    boolean blue = true;

    /**
     * konstruktor okolitej bunky
     * @param p - pane
     * @param startX - stred bunky suradnica X
     * @param startY - stred bunky suradnica Y
     * @param startDirX - vektor v smere suradnice X
     * @param startDirY - vektor v smere suradnice Y
     * @param m - hmotnost bunky
     */
    public EjectedCell(UniversePane p, double startX, double startY, double startDirX, double startDirY, double m){
        this.p = p;

        this.centerX = startX;
        this.centerY = startY;
        this.dirX = startDirX/Osmos.c;
        this.dirY = startDirY/Osmos.c;

        this.m = m;
        this.radius = Math.sqrt(m) * Osmos.c;

        setCenterX(centerX);
        setCenterY(centerY);
        setRadius(radius);
        setFill(Osmos.BLUE);

    }

    /**
     * pohyb okolitej bunky a odrazanie od stien + aby sa netvorili za okrajom
     */
    public void move(){
        if (getLayoutBounds().getMaxX() + dirX > p.getWidth() || getLayoutBounds().getMinX() + dirX < 0) {
            dirX = -dirX;
        }
        if (getLayoutBounds().getMaxY()  + dirY > p.getHeight() || getLayoutBounds().getMinY() + dirY < 0) {
            dirY = -dirY;
        }

        if(centerX - radius <= 0) centerX = radius+1;
        else if(centerX + radius >= p.getWidth()) centerX = p.getWidth() - radius-1;
        if(centerY - radius <= 0) centerY = radius+1;
        else if(centerY + radius >= p.getHeight()) centerY = p.getHeight() - radius-1;

        centerX += dirX;
        centerY += dirY;
        setCenterX(centerX);
        setCenterY(centerY);

    }

    /**
     * updatne radius bunky a vypln
     * @param player - bunka hraca
     * @param radius - polomer bunky
     */
    public void update(double radius, PlayerCell player){
        setRadius(Math.sqrt(getM()) * Osmos.c);
        if(blue && m >= player.getM()){
            setFill(Osmos.RED);
            blue = false;
        }
        else if(!blue && m < player.getM()){
            setFill(Osmos.BLUE);
            blue = true;
        }
    }

    public boolean getBlue(){
        return blue;
    }
    public double getDirX() {
        return dirX;
    }
    public double getDirY() {
        return dirY;
    }
    public double getM() {
        return m;
    }
    public void setDirX(double dirX) {
        this.dirX = dirX;
    }
    public void setDirY(double dirY) {
        this.dirY = dirY;
    }
    public void setM(double m) {
        this.m = m;
    }
}

class UniversePane extends Pane {

    /**
     * hracia plocha
     */
    public UniversePane(){
        setStyle("-fx-background-image: url('img/background.jpg');" +
                "-fx-background-repeat: stretch;" +
                "-fx-background-size: cover;" +
                "-fx-background-position: center center;");
    }
}

class Menu extends VBox {
    double width;
    double height;
    Text title;
    Button b0,b1,b2,b3,b4,b5,b6,b7;

    /**
     * herne menu
     * @param p - pane
     * @param height - vyska menu okna
     * @param width - sirka menu okna
     */
    public Menu(UniversePane p, double width, double height) {
        this.width = width;
        this.height = height;

        PlayerCell titleCell = new PlayerCell(p,0,0,0,0,0);
        titleCell.setRadius(25);

        title = new Text("OSMOS");
        title.setFill(Color.WHITE);
        title.setId("title");

        setStyle("-fx-background-image: url('img/background.jpg');" +
                "-fx-background-repeat: stretch;" +
                "-fx-background-size: cover;" +
                "-fx-background-position: center center;");

        setAlignment(Pos.CENTER);
        setSpacing(10);

        b0 = new Button("Level 0");
        b0.getStyleClass().add("button");

        b1 = new Button("Level 1");
        b1.getStyleClass().add("button");

        b2 = new Button("Level 2");
        b2.getStyleClass().add("button");

        b3 = new Button("Level 3");
        b3.getStyleClass().add("button");

        b4 = new Button("Random");
        b4.getStyleClass().add("button");

        b5 = new Button("SAVE");
        b5.getStyleClass().add("button");

        b6 = new Button("LOAD");
        b6.getStyleClass().add("button");

        b7 = new Button("QUIT");
        b7.getStyleClass().add("button");

        getChildren().addAll(titleCell,title, b0, b1, b2, b3, b4, b5, b6, b7);
    }
}